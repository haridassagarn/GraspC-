#include <iostream>
#include "bike.hpp"

using namespace std;

void bike::create_vehicle()
{

	cout << "creating bike " << endl;
}
