#ifndef vehicle_hpp
#define vehicle_hpp

class vehicle
{
  public:
    virtual void create_vehicle()=0;

};

#endif
