#include "vehicleFactory.hpp"


int main(int argc,char* argv[])
{
	string vehType;

	cin>>vehType;



	vehicle *obj = vehicleFactory::getvehicle(vehType); //factory class makes possible to not know what specifc vehicle objects can be present
	obj->create_vehicle();


	return 0;
}
