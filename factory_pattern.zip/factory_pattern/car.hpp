#ifndef car_hpp
#define car_hpp

#include "vehicle.hpp"

class car : public vehicle
{
	public:
	void create_vehicle();


};

#endif
