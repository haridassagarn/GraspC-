
#include "vehicleFactory.hpp"

vehicle* vehicleFactory::getvehicle(string vehicleType)
{
                 vehicle* vehicleobj;
		if(vehicleType == "car")
		{
		  vehicleobj = new car();
		}
		if(vehicleType == "bike")
		{
		  vehicleobj = new bike();
		}
	
		return vehicleobj;

}


