#ifndef bike_hpp
#define bike_hpp

#include "vehicle.hpp"

class bike : public vehicle
{
	public:
	void create_vehicle();


};

#endif
