#ifndef vehicleFactory_hpp
#define vehicleFactory_hpp

#include <iostream>
#include "car.hpp"
#include "bike.hpp"
using namespace std;

class vehicleFactory
{
public:
       static vehicle *getvehicle(string vehicleType);

};

#endif
