#include <iostream>
#include "car.hpp"

using namespace std;

void car::create_vehicle()
{

	cout << "creating car " << endl;
}
